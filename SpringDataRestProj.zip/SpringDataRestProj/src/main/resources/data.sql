insert into alien values (101,'Navin','java');
insert into alien values (102,'Navins','java2');
insert into alien values (103,'Navind','java4');