package org.simu.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataRestProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataRestProjApplication.class, args);
	}
}
